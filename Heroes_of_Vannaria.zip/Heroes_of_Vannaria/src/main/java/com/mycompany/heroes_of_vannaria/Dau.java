/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.heroes_of_vannaria;

/**
 *
 * @author eric9
 */
public class Dau {
    
    private int cares;
    
    public Dau(int cares){
        this.cares=cares;
    }
    
    public int Tirada(){
        return (int)(Math.random()*cares) + 1;
    }

    int tirada() {
        throw new UnsupportedOperationException("Not supported yet.");
    }
}

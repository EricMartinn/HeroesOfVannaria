/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.heroes_of_vannaria;

import java.util.Scanner;

/**
 *
 * @author eric9
 */
public class Utils {
    
    public static int llegeixEnterRang(String missatge,int min,int max) {
        
        Scanner sc = new Scanner(System.in);
        boolean correcte = false;
        
        int resultat = -1;
        while(!correcte) {
            System.out.printf(missatge + " [%d-%d]: ",min,max);
            String entradaUsuari = sc.nextLine();
            
            try {
                resultat = Integer.parseInt(entradaUsuari);
                if(resultat<min || resultat>max) {
                    System.out.println("L'entrada no és vàlida!");
                    resultat = -1;
                } else
                    correcte = true;
            } catch (NumberFormatException e) {
                System.out.println("L'entrada no és vàlida!");
                resultat = -1;
            }
        }
        return resultat;
    }

}
